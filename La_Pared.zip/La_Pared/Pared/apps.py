from django.apps import AppConfig


class ParedConfig(AppConfig):
    name = 'Pared'
